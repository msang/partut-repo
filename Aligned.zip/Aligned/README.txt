This folder is structured as follows:

\Aligned
	|
	|__\language pair
			|
			|___\CoNLL
			|___partut-src_trg.out
			|___partut-src2trg.aligned
			|___partut-trg2src.aligned
			
			
Each \CoNLL folder, in turn, contains only the annotated sentences in the respective language pair with a 1:1 correspondence, 
while the .aligned files contain the word alignment output, and the .out files display the output in a matrix. 

Alignment files are formatted in a Moses-like fashion: each line represents a sentence
pair and each alignment point is represented as a (zero-indexed) pair i-j indicating that the i-th word  
of the source sentence is aligned to the j-th word of the target sentence.